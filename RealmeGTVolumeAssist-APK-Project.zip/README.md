# Realme GT Master Edition - Virtual Volume Bubble APK

Controls **Media Volume**, **Ring Volume**, and **In-Call Earpiece Volume** via a floating Realme UI yellow bubble.

## How to Get Your .APK File Without a Computer (GitHub Cloud Build):
1. Create a free account on [GitHub.com](https://github.com) and create a new repository.
2. Upload all the files inside this ZIP folder to your repository.
3. Click the **Actions** tab at the top of your GitHub repository.
4. Wait ~60 seconds for the **"Build Realme GT Volume Assist APK"** workflow to finish.
5. Download **Realme-GT-Volume-Assist-APK** and install `app-debug.apk` on your Realme GT Master Edition!
package com.realme.gtvolumeassist

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs

class FloatingVolumeService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var audioManager: AudioManager
    private lateinit var floatingBubble: View
    private lateinit var volumePanel: LinearLayout
    private var isPanelExpanded = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        createFloatingBubble()
        createRealmeVolumePanel()
    }

    private fun createFloatingBubble() {
        val bubbleButton = Button(this).apply {
            text = "🔊"
            textSize = 18f
            setTextColor(Color.BLACK)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#FFC915")) // Realme Yellow
                setStroke(4, Color.WHITE)
            }
        }

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            145, 145,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 400
        }

        // Drag and Tap listener for the Floating Bubble
        bubbleButton.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(floatingBubble, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val diffX = abs(event.rawX - initialTouchX)
                        val diffY = abs(event.rawY - initialTouchY)
                        if (diffX < 15 && diffY < 15) {
                            togglePanel()
                        }
                        return true
                    }
                }
                return false
            }
        })

        floatingBubble = bubbleButton
        windowManager.addView(floatingBubble, params)
    }

    private fun createRealmeVolumePanel() {
        volumePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
            background = GradientDrawable().apply {
                cornerRadius = 56f
                setColor(Color.parseColor("#EE1E2025")) // Realme Dark Card
                setStroke(2, Color.parseColor("#44FFFFFF"))
            }
            visibility = View.GONE
        }

        val title = TextView(this).apply {
            text = "REALME GT SOUND HUB"
            setTextColor(Color.parseColor("#FFC915"))
            textSize = 14f
            setPadding(0, 0, 0, 24)
        }
        volumePanel.addView(title)

        // 1. Media Volume Slider (STREAM_MUSIC)
        volumePanel.addView(buildStreamSlider("🎵 Media Volume", AudioManager.STREAM_MUSIC))

        // 2. Ring Volume Slider (STREAM_RING)
        volumePanel.addView(buildStreamSlider("🔔 Ring Volume", AudioManager.STREAM_RING))

        // 3. Phone Call Earpiece Slider (STREAM_VOICE_CALL)
        volumePanel.addView(buildStreamSlider("📞 Call Earpiece Volume", AudioManager.STREAM_VOICE_CALL))

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val panelParams = WindowManager.LayoutParams(
            850,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        windowManager.addView(volumePanel, panelParams)
    }

    private fun buildStreamSlider(label: String, streamType: Int): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 16, 0, 16)
        }

        val maxVol = audioManager.getStreamMaxVolume(streamType)
        val curVol = audioManager.getStreamVolume(streamType)

        val header = TextView(this).apply {
            text = "$label ($curVol / $maxVol)"
            setTextColor(Color.WHITE)
            textSize = 13f
        }

        val seekBar = SeekBar(this).apply {
            max = maxVol
            progress = curVol
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        audioManager.setStreamVolume(
                            streamType,
                            progress,
                            AudioManager.FLAG_PLAY_SOUND
                        )
                        header.text = "$label ($progress / $maxVol)"
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

        container.addView(header)
        container.addView(seekBar)
        return container
    }

    private fun togglePanel() {
        isPanelExpanded = !isPanelExpanded
        volumePanel.visibility = if (isPanelExpanded) View.VISIBLE else View.GONE
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::floatingBubble.isInitialized) windowManager.removeView(floatingBubble)
        if (::volumePanel.isInitialized) windowManager.removeView(volumePanel)
    }
}
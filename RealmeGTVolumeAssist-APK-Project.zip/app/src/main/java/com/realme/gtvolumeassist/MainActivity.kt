package com.realme.gtvolumeassist

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
            setBackgroundColor(Color.parseColor("#121316"))
        }

        val title = TextView(this).apply {
            text = "realme GT Master Edition\nVirtual Volume Bubble"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 48)
        }

        val startBtn = Button(this).apply {
            text = "Enable Floating Volume Bubble"
            textSize = 15f
            setTextColor(Color.BLACK)
            background = GradientDrawable().apply {
                cornerRadius = 36f
                setColor(Color.parseColor("#FFC915"))
            }
            setPadding(48, 36, 48, 36)
            setOnClickListener {
                checkAndStartBubble()
            }
        }

        val stopBtn = Button(this).apply {
            text = "Hide Volume Bubble"
            textSize = 14f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 36f
                setColor(Color.parseColor("#2A2D35"))
            }
            setPadding(48, 30, 48, 30)
            setOnClickListener {
                stopService(Intent(this@MainActivity, FloatingVolumeService::class.java))
                Toast.makeText(this@MainActivity, "Bubble Hidden", Toast.LENGTH_SHORT).show()
            }
        }

        layout.addView(title)
        layout.addView(startBtn)
        val spacer = TextView(this).apply { height = 32 }
        layout.addView(spacer)
        layout.addView(stopBtn)

        setContentView(layout)
        checkAndStartBubble()
    }

    private fun checkAndStartBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please grant 'Display over other apps' permission", Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, 101)
        } else {
            startService(Intent(this, FloatingVolumeService::class.java))
            Toast.makeText(this, "Realme GT Volume Bubble Active!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && Settings.canDrawOverlays(this)) {
            startService(Intent(this, FloatingVolumeService::class.java))
            finish()
        }
    }
}